const express = require("express");
const path = require("path");
var bodyParser = require('body-parser');
var app = express();

app.get("/bookdetails", (req, res) => {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var books = require('./book.js');
    var Books = mongoose.model('books', books);

    mongoose.connect("mongodb://localhost/SampleDB").then(() => {
        var db = mongoose.connection.db;
        console.log("database connected to " + db.databaseName);
        var books = new Books();
        Books.find((err, docs) => {
            if (!err) {
                console.log("retrived data successfully");

                console.log(docs);
                res.json(docs);
                db.close();
                res.end();

                console.log("Connection disconnected");
            } else {
                console.log("error inside" + err);
            };
        });
    }, (err) => {
        console.log("error occured at " + err);


    });

});

app.use(bodyParser.urlencoded({ extended: true }));
app.post("/addDetails", (req, res) => {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var books = require('./book.js');
    var Books = mongoose.model('books', books);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {
        var db = mongoose.connection.db;
        console.log("database connected to " + db.databaseName);
        var books = new Books({
            "_id": req.body.id,
            "name": req.body.name,
            "dop": req.body.dop,
            "author": req.body.author,
            "isAvailable": req.body.available,
            "fileForm": req.body.file

        });
        books.save(function (err) {
            if (!err) {
                db.close();
                res.send("New Book is Added into Library Successfully");
            } else {
                res.redirect("/add", { msg: 'Please try again' });
            }
        });


    }, (err) => {
        console.log("error occured at " + err);

    });

});

app.get('/findonebookDetails', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var books = require('./book.js');
    var Books = mongoose.model('books', books);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        console.log("database connected to " + db.databaseName);
        console.log(req.query['id']);
        var query = Books.where("_id").equals(req.query['id']);
        query.exec((err, doc) => {
            if (!err) {
                console.log("retrived successfully" + doc);
                //res.send(JSON.stringify(doc));

                res.json(doc);
                db.close();
                res.end();
                console.log("disconnected");
            } else {

                console.log("error inside" + err);
            }
        });

    });
});

app.post('/update', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var books = require('./book.js');
    var Books = mongoose.model('books', books);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        console.log("database connected to " + db.databaseName);
        console.log(req.query['id']);
        var query = Books.where("_id").equals(req.query['354324id']);
        var book = new Books();
        Books.update({ "_id": req.body.bookid }, {
            $set: {

                "name": req.body.name,
                "dop": req.body.dop,
                "author": req.body.author,
                "isAvailable": req.body.available,
                "fileForm": req.body.file
            }
        }, function (err, user) {
            if (err) {
                res.json({ error: err });
                db.close();

                res.end();
            } else {

                db.close();
                res.send("<h1>Updated successfully</h1>");

                res.end();
            }
        });
    });
});

app.post("/delete", (req, res) => {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var books = require('./book.js');
    var Books = mongoose.model('books', books);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        console.log("database connected to " + db.databaseName);
        var book = new Books();
        Books.findByIdAndRemove({ "_id": req.body.bookid }, function (err, doc) {


            console.log(req.body.bookid);
            res.send("<h1> Deleted Successfilly</h1>");
            db.close();
            res.end();
        });
    }, (err) => {
        console.log("error occured" + err);
    });
});

app.post('/login', function (req, res) {
    const mongoose = require("mongoose");
    mongoose.Promise = require("bluebird");
    var logins = require('./login.js');
    var Logins = mongoose.model('logins', logins);
    mongoose.connect("mongodb://localhost/SampleDB").then(() => {

        var db = mongoose.connection.db;
        var login = new Logins();
        console.log("database connected to " + db.databaseName);
        Logins.find({ "uname": req.body.username, "pass": req.body.password }, function (err, doc) {
            if (!err) {
                if (doc.length == 0) {
                    res.send("Please Check your login details");
                } else {
                    res.redirect("/start");
                }
                db.close();
                res.end();
            } else {
                res.send(err);
                db.close();
                res.end();

            }
            },(err) => {
                res.send(err);
                res.end();



            });
    });
});

app.get("/deletebook", (req, res) => {
    var newPath = path.resolve(__dirname, "delete.html");
    console.log(__dirname);
    res.sendFile(newPath);
});

app.get("/updatebook", (req, res) => {
    var newPath = path.resolve(__dirname, "update.html");
    console.log(__dirname);
    res.sendFile(newPath);
});


app.get("/findone", (req, res) => {
    var newPath = path.resolve(__dirname, "find.html");
    console.log(__dirname);
    res.sendFile(newPath);
});

app.get("/add", (req, res) => {
    var newPath = path.resolve(__dirname, "addbook.html");
    console.log(__dirname);
    res.sendFile(newPath);
});

app.get("/showall", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "alldetails.html");
    res.sendFile(indexViewPath);
});

app.get("/start", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "start.html");
    res.sendFile(indexViewPath);
});

app.get("/welcome", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "about.html");
    res.sendFile(indexViewPath);
});

app.get("/", (req, res) => {
    var indexViewPath = path.resolve(__dirname, "login.html");
    res.sendFile(indexViewPath);
});


app.listen(3000, () => {
    console.log("starting on localhost 3000");
});