var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bookSchema = new Schema({
        "_id" : Number, 
        "name" :String,
        "dop":String,
        "author" :String,
        "isAvailable" : Boolean,
        "fileForm":String
    });

module.exports = bookSchema;