const mongodb = require('mongodb');
var MongoClient = mongodb.MongoClient;

MongoClient.connect('mongodb://10.219.32.32/SampleDB',function(err,db){
    if(err){
        console.log('Error occured:'+err);
    }
    else{
        console.log('Connected to :'+db.databaseName);
        db.close();
        console.log('Disconnected');
    }
});