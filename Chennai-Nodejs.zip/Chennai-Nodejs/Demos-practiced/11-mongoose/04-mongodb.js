const mongoose = require('mongoose');
mongoose.Promise = require('q').Promise;

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    var db = mongoose.connection.db;
    var Schema  = mongoose.Schema;
    var Department = mongoose.model('department',new Schema({
        name: String
    }));

    var department = new Department({name:'HR'});

    department.save((err,doc)=>{
        if(!err){
            console.log('Document Saved : '+doc);
        }else{
            console.log(err);
        }
        db.close();
    });
},(err)=>{
    console.log('Problem in connecting DB:'+err);
});