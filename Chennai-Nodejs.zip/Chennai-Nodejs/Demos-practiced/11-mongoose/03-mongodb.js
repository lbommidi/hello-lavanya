const mongoose = require('mongoose');
mongoose.Promise = require('q').Promise;
mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    var db = mongoose.connection.db;
    console.log('Connected to DB : '+db.databaseName);
    db.close();
    console.log('Disconnected');
},(err)=>{
    console.log('Error occured in connecting DB');
});