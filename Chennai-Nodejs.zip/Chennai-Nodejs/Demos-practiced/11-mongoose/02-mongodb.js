const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/SampleDB',function(err){
    if(err){
        console.log('Error Occured in Connection');
    }else{
        var db = mongoose.connection.db;
        console.log('Connected to DB : '+db.databaseName);
        db.close();
        console.log('Disconnected');
    }
});