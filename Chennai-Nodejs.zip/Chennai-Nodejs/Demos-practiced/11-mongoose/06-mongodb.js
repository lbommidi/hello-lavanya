const mongoose = require('mongoose');
mongoose.Promise = require('q').Promise;

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    var db = mongoose.connection.db;
    var Schema  = mongoose.Schema;
    var Employee = mongoose.model('employee',new Schema({
        _id : Number, 
        name : { 
            first : String, 
            last : String 
        }, 
        doj : Date, 
        location : String, 
        isActive : Boolean, 
        email : String, 
        qualifications :[String]
    }));
    
    /*Employee.findOne({_id:3861},(err,doc)=>{
        if(!err){
            doc.email = 'veena.deshpande@capgemini.com';
            doc.save((err,doc)=>{
                if(!err){
                    console.log('Document Updated');
                    console.log(doc);
                    db.close();
                }
            });
        }
    });*/

    Employee.update({_id:3861},{email:'test@tet.com'},(err,doc)=>{
        if(!err){
            console.log(doc);
        }
        db.close();
    });


},(err)=>{
    if(err)
    console.log('Error in Connecting DB');
});






