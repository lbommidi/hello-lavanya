const mongoose = require('mongoose');
mongoose.Promise = require('q').Promise;

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    var db = mongoose.connection.db;
    var Schema  = mongoose.Schema;
    var Location = mongoose.model('location',new Schema({
        _id: Number,
        city: String
    }));
   /*Location.find((err,docs)=>{
        if(!err){
            docs.forEach((doc)=>{
                console.log('Id:'+doc._id+'Name: '+doc.city);
            });
        }
        else{
            console.log(err);
        }
        db.close();
   });
  Location.find({_id:{$gte:2}},{_id:0,city:1},{limit:3},(err,docs)=>{
    if(!err)
        console.log(docs);
    db.close();
  });
  Location.findOne((err,doc)=>{
    if(!err)
        console.log(doc);
    db.close();
  });
 Location.findById(4,(err,doc)=>{
    if(!err)
        console.log(doc);
    db.close();
 });*/
 var query = Location.where('_id').gte(2).lt(6).where('city').in(['Chennai','Mumbai']);
query.exec((err,docs)=>{
    if(!err)
        console.log(docs);
    db.close();
});

},(err)=>{
    console.log('Problem in connecting DB:'+err);
});





