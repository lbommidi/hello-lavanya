var firstName = 'Karthik';
var lastName = 'Muthukrishnan';
var fullName = `${ firstName } ${ lastName }`;
var multiLine = `One
Two
Three`;