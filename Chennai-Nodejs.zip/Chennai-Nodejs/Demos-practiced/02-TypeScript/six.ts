var addNumbers = (a:number,b:number):number => a +b;
var square = (n:number):number => n * n;
