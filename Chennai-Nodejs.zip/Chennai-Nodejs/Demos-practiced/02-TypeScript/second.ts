class Foo{
    private name:string;
    get Name():string{
        return this.name;
    }
    set Name(name:string){
        this.name = name;
    }
    constructor(){
        this.name = '';
    }
    getDetails():string{
        return 'Name: '+this.name;
    }
}