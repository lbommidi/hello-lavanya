interface Person{
    firstName:string,
    lastName:string
}
interface IFoo{
    print(data:string):string;
}
var sample = (obj:Person)=>{
    console.log(`${obj.firstName} ${obj.lastName}`);
}
sample({firstName:'',lastName:''});
class Foo implements IFoo{
    print(data:string):string{
        return '';
    }
}










