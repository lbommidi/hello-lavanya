function sample(){
    let i = 5;
    if(true){
        let i = 10;
        console.log(i); 
    }
    console.log(i); 
}
sample();