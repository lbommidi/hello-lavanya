enum Salutation {Mr,Ms,Mrs,Dr}

var personAge:number = 22;
var personName:string = 'Karthik';
var activeStatus:boolean = true;
var title:Salutation = Salutation.Mr;
