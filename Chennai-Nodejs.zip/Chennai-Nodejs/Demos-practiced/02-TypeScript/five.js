function sample() {
    var i = 5;
    if (true) {
        var i_1 = 10;
        console.log(i_1);
    }
    console.log(i);
}
sample();
