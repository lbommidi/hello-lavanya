module.exports = function(n){
    return n * n;
}