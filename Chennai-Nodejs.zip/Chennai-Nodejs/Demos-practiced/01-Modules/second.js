var os = require('os');
var path = require('path');
console.log(path.join(__dirname,'app'));
console.log(os.platform());