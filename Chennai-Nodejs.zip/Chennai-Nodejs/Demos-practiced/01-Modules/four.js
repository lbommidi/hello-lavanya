var square = require('./fourth');
console.log(square(4));