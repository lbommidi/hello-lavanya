var test = require('./thirdmodule');
console.log(test.add(5,6));