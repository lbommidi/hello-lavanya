const express = require('express');
const path = require('path');
var app = express();

app.set('views',path.join(__dirname,'views'));
app.set('view engine','jade');

app.all('*',(req,res)=>{
    res.render('index',{title:'Capgemini',message:'Capgemini Chennai Sipcot'});
});

app.listen(3000,()=>{
    console.log('Listening on port 3000 at localhost');
});