var addNumbers = function(a,b){
    var result;
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            result = a + b;
            resolve(result);
        },2000);
    });
}
var addPromise = addNumbers(4,5);
addPromise.then((data)=>{
    console.log('Addition result : '+data);
});









