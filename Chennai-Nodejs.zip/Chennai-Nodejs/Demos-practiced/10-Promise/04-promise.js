var promiseObj = new Promise((resolve,reject)=>{
    try{
        var randomNumber = Math.round(Math.random()*10);
        if(randomNumber >= 5)
            resolve(randomNumber);
        else
            throw 'NumberLessThanFive Exception Occured:'+randomNumber;
    }
    catch(err){
        reject(err);
    }
});
promiseObj.then((data)=>{
    console.log('Random Number Generated: '+data);
},(err)=>{
    console.log(err);
});






















