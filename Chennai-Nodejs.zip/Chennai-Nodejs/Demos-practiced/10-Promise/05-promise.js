var addNumbers = function(a,b){
    var result;
    return new Promise((resolve,reject)=>{
         setTimeout(()=>{
            result = a + b;
            resolve(result);
        },Math.round(Math.random()*1000));
    });
}
var squareNumber = function(n){
    var result;
    return new Promise((resolve,reject)=>{
         setTimeout(()=>{
            result = n * n;
            resolve(result);
        },Math.round(Math.random()*1000));
    });
}
var addPromise = addNumbers(4,5);
var squarePromise = squareNumber(4);
var allPromise = Promise.race([addPromise,squarePromise]);
allPromise.then((result)=>{
    console.log('Addition Result:'+result);
    console.log('Square Number Result:'+result);
},(err)=>{
    console.log(err);
});















