var promiseObj = new Promise(function(resolve,reject){
    //resolve(5);
    reject('Error Occured');
});

promiseObj.then((data)=>{
    console.log('Promise Fullfilled :'+data);
},(err)=>{
     console.log('Promise Rejected :'+err);
});