//var promiseObj = Promise.resolve(5);
var promiseObj = Promise.reject('Error occured');
promiseObj.then(function(data){
    console.log('Promise Fullfilled:'+data);
},function(err){
    console.log('Promise Rejected:'+err);
});
