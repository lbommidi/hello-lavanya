const events = require('events');
let AppEventEmitter = new events.EventEmitter();

let cb = (data)=>{
    console.log('CG-Event Occured with : '+data);
}
AppEventEmitter.addListener('cgEvent',cb);
AppEventEmitter.emit('cgEvent','Capgemini-1');
AppEventEmitter.removeListener('cgEvent',cb);
AppEventEmitter.emit('cgEvent','Capgemini-2');











