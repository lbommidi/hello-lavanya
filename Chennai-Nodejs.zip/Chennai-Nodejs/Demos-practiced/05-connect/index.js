const connect = require('connect');
var app = connect();
app.use('/admin',(req,res,next)=>{
    console.log('Admin Logger');
    next();
});

app.use('/admin',(req,res)=>{
    res.end('<h1>Admin home Page</h1>')
});

app.use('/guest',(req,res,next)=>{
    console.log('Guest Logger');
    next();
});

app.use('/guest',(req,res)=>{
    res.end('<h1>Guest Page</h1>')
});

app.use('/',(req,res,next)=>{
    console.log(req.url);
    console.log('Home Logger');
    next();
});

app.use('/',(req,res)=>{
    res.end('<h1>Home Page</h1>')
});
app.listen(3000,()=>{
    console.log('Listening on port 3000 at localhost');
});