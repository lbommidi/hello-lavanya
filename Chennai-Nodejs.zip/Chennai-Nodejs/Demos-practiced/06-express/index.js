const express = require('express');
var app = express();
var root = express.Router();
var admin = express.Router();

app.use('/',root);
app.use('/admin',admin);

root.get('/',(req,res)=>{
    res.end('<h1>Home Page</h1>');
});

root.get('/err',(req,res,next)=>{
    next({title:'Cg-Error',message:'Error occured in Server'});
});

admin.get('/',(req,res)=>{
    res.end('<h1>Admin Page</h1>');
});

admin.get('/test',(req,res)=>{
    res.end('<h1>Admin Test Page</h1>');
});

admin.get('/:name',(req,res)=>{
    res.end('<h1>Admin Path Param Page:'+req.params.name+'</h1>');
});

root.use((err,req,res,next)=>{
    res.status(500);
    res.write('<h1>'+err.title+'</h1>');
    res.end('<p>'+err.message+'</p>');
});

app.listen(3000,()=>{
    console.log('Listening on port 3000 at localhost');
});






