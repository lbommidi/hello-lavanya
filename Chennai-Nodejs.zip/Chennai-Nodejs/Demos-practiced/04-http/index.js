const http = require('http');
var server = http.createServer((request,response)=>{
    response.write('<h1>Capgemini</h1>');
    response.end();
});
server.listen(3000,()=>{
    console.log('Server started at localhost:3000');
});