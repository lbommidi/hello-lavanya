const path = require('path');
const express = require('express');
const app = express();

app.set('views',path.join(__dirname,'views'));
app.set('view engine','jade');


app.all('*',(req,res)=>{
    res.render('index',{company:'Capgemini India'});
});

app.listen(3000,()=>{
    console.log('Listening on Port 3000 at localhost');
});