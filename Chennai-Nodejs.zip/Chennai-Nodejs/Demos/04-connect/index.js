const connect = require('connect');
const app = connect();

app.use('/guest',(request,response,next)=>{
    console.log('Guest Logger');
    next();
});
app.use('/guest',(request,response,next)=>{
    response.end('<h1>Guest Home</h1>');
});
app.use('/admin',(request,response,next)=>{
    console.log('Admin Logger');
    next();
});
app.use('/admin',(request,response,next)=>{
    response.end('<h1>Admin Home</h1>');
});
app.use('/',(request,response,next)=>{
    console.log('Home Logger');
    next();
});
app.use('/',(request,response,next)=>{
    response.end('<h1>Home</h1>');
});
app.listen(3000,()=>{
    console.log('Listening on port 3000 at localhost');
});

