const express = require('express');
const app = express();

app.get('/',(req,res)=>{
    res.send('<h1>Welcome to JS unit Testing</h1>');
});

app.post('/',(req,res)=>{
    res.json({name:'Karthik'});
});

module.exports = app;
