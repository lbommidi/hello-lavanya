const http = require('http');

let server = http.createServer((request,response)=>{
    response.write('<h1>Welcome to Capgemini - India</h1>');
    response.end();
});

server.listen(3000,()=>{
    console.log('Listening on port 3000');
});
