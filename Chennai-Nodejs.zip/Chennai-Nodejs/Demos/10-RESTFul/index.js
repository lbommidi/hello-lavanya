const express = require('express');
const mongoose = require('mongoose');
mongoose.promise = require('bluebird');
const bodyParser = require('body-parser');
const app = express();
const api = express.Router();

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{

    // parse application/x-www-form-urlencoded 
    app.use(bodyParser.urlencoded({ extended: false }));
 
    // parse application/json 
    app.use(bodyParser.json());

    app.use('/',(req,res,next)=>{
        res.set('X-Powered-By','Karthik');
        next();
    });

    app.use('/api/guests',api);

    app.get('/',(req,res)=>{
        res.send('<h1>Welcome to RESTFul Services</h1>');
    });

    let Schema = mongoose.Schema;
    let Guest = mongoose.model('guest',new Schema({
        name: String,
        contactNumber: String
    }));

    api.get('/',(req,res)=>{
        Guest.find((err,guestDocs)=>{
            if(err){
                res.status(500).send(err);
            }
            else{
                res.json(guestDocs);
            }
        })
    });

    api.get('/:id',(req,res)=>{
      Guest.findById(req.params.id,(err,guestDoc)=>{
            if(err){
                res.status(500).send(err);
            }
            else{
                res.json(guestDoc);
            }
      });
    });

    /*Creating Guest Resource */
    api.post('/',(req,res)=>{
        let guest = new Guest({
            name: req.body.name,
            contactNumber: req.body.contactNumber
        });

        guest.save((err,guestDoc)=>{
            if(err)
                res.status(500).send(err);
            else
                res.status(201).send(guestDoc);
        });
    });
    
    api.put('/:id',(req,res)=>{
       Guest.findById(req.params.id,(err,guestDoc)=>{
            if(err){
               res.status(500).send(err);
            }
            else if(guestDoc){
               Guest.update({_id:guestDoc._id},(err)=>{
                    guestDoc.name = req.body.name;
                    guestDoc.contactNumber = req.body.contactNumber;
                    guestDoc.save((err)=>{
                       if(err) 
                            res.status(500).send(err);
                        else
                            res.send(204);
                    });
               });
            }
            else{
                res.status(404).send('No Guest Found');
            }
      });
    });
    
    api.delete('/:id',(req,res)=>{
      Guest.findById(req.params.id,(err,guestDoc)=>{
            if(err){
               res.status(500).send(err);
            }
            else if(guestDoc){
                Guest.remove({_id:guestDoc._id},(err)=>{
                    if(err)
                       res.status(500).send(err);
                    else
                        res.send(204);
                });
            }
            else{
                res.status(404).send('No Guest Found');
            }
      });
    });
},(err)=>{
    app.get('/',(req,res)=>{
        res.send('<h1>Error in connecting DB');
    });
});

app.listen(3000,()=>{
    console.log('Listening on port 3000 at localhost');
});