const express=require('express');
const path = require('path');
const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');
const app = express();

app.set('views',path.join(__dirname,'views'));
app.set('view engine','jade');

let connection = mongoose.connect('mongodb://localhost/SampleDB');
connection.then(()=>{
    let db = mongoose.connection.db;
    let Schema = mongoose.Schema;

    let Employee = mongoose.model('employee',new Schema({
        _id: Number,
        name:{ first: String, last:String},
        doj: Date,
        location: String,
        isActive: Boolean,
        email:String,
        qualification: [String]
    }));

    let employees = [];
    
    Employee.find({},{'name.first':1,'email':1,'location':1},(err,docs)=>{
        employees = docs;
        db.close();
    })

    app.get('/',(req,res)=>{
         res.render('index',{'employees':employees});
    });

},(err)=>{
    app.use('/',(req,res,next)=>{
        res.send('<h1>Error in connecting DB</h1>');
    });
});

app.listen('3000',()=>{
    console.log('Listening on port 3000 at localhost');
});