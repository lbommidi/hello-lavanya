module.exports = function multiply(a,b){
    return a * b;
}