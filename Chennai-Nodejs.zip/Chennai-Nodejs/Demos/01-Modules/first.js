setInterval(function(){
    console.log('Hi');
},1000);