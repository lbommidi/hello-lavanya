var  multiply = require('./fourthmodule');
console.log(multiply(5,6));