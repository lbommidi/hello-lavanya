const events = require('events');
let AppEvent = new events.EventEmitter();

let fn1 = (data)=>{
    console.log('fn1 Invoked:'+data);
}
let fn2 = ()=>{
    console.log('fn2 Invoked');
}
AppEvent.addListener('cgEvent',fn1);
AppEvent.addListener('cgEvent',fn2);

AppEvent.removeListener('cgEvent',fn2);

AppEvent.emit('cgEvent','Data for Fn1');
AppEvent.emit('cgEvent','Data for Fn1');



