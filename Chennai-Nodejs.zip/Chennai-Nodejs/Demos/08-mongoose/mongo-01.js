const mongodb = require('mongodb');
let MongoClient = mongodb.MongoClient;
MongoClient.connect('mongodb://localhost/SampleDB',(err,db)=>{
    if(err){
        console.log('Error:'+err);
    }
    else{
        console.log('Connected to database: '+db.databaseName);
        db.close();
        console.log('Disconnected');
    }
});