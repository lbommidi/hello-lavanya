const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');
mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;
    console.log('Connected to :'+db.databaseName);
    db.close();
    console.log('Disconnected');
},(err)=>{
    console.log('Error Occured:'+err);
});