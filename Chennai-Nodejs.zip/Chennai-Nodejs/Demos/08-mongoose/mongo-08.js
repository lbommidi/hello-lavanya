const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;
    let Schema = mongoose.Schema;

    let Person = mongoose.model('person',new Schema({
        name: { type: String, required:[true,'Name is required'], match:[/^[a-zA-Z]+$/,'Only Alphabets Allowed'] },
        age : { type: Number, min:[30,'Age must be minimum 30'], max:[40,'Age must be maximum 40'] },
        salutation: { type: String, enum:['Mr','Ms','Mrs','Dr'] },
        status: { type: String, default:'Alive' },
        location: { type:String, validate:{
            validator: (val)=>{
                return val.length>=5 && val.length<=10;
            },
            message:'Location must be between 5 to 10 characters'
        }}
    }));

    let person = new Person({
        name: '88',
        age: 1,
        salutation: 'Mr',
        location: 'Kenyadfgkljfgldfgn'
    });

    person.save((err,doc,rowsAffected)=>{
        if(err){
            var validationError = {};
           for(var errKey in err.errors){
               validationError[errKey] = err.errors[errKey].message;
           }
           console.log(validationError);
           db.close();
        }
        else {
            console.log('Person Added');
            console.log(doc);
            db.close();
        }
    });
},(err)=>{
    console.log('Error:'+err);
});