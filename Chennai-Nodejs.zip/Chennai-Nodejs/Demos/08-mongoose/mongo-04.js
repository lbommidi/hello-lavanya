const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;
    console.log('Connected to db: '+db.databaseName);

    let Schema = mongoose.Schema;

    let Department = mongoose.model('department',new Schema({
        name: String
    }));

    let department = new Department({name:'Training'});

    department.save((err,doc,affectedRows)=>{
        if(err){
            console.log('Error Occured:'+err);
        }
        else{
            console.log('Record Added:'+doc);
            db.close();
            console.log('Disconnected');
        }
    });

},(err)=>{
    console.log('Error Occrured : '+err);
});