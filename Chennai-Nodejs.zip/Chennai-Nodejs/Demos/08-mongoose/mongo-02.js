/*Connecting MongoDB using mongoose - Callback */
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/SampleDB',(err)=>{
    let db = mongoose.connection.db;
    console.log('Connected to :'+db.databaseName);
    db.close();
    console.log('Disconnected');
});