const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;
    console.log('Connected:'+db.databaseName);

    let Schema = mongoose.Schema;

    let Location = mongoose.model('location',new Schema({
        _id: Number,
        location: String
    }));

    /*let query = Location.find({});
    
    query.exec().then((locations)=>{
        console.log(locations);
        db.close();
        console.log('Disconnected');
    },(err)=>{
        console.log('Error:'+err);
    });*/

    Location.find((err,locations)=>{
        if(err){
            console.log('Error:'+err);
        }
        else{
            console.log(locations);
            db.close();
            console.log('Disconnected');
        }
    });
},(err)=>{
    console.log('Error Occured:'+err);
});