const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;

    let Schema = mongoose.Schema;

    let Employee = mongoose.model('employee',new Schema({
        _id: Number,
        name: {
            first: String,
            last: String
        },
        doj: { validate:[()=>{},] },
        location: String,
        isActive: Boolean,
        email: String,
        qualifications: [String]
    },{collection:'employees'}));

   Employee.findOne({_id:714709},(err,employee)=>{
        if(err)
            console.log('Error:'+err);
        else{
            employee.name.last = 'M';
            employee.qualifications.splice(1,1);
            employee.save((err,employee,rowsAffected)=>{
                if(err)
                    console.log('Error:'+err);
                else{
                    console.log('Employee Updated');
                    console.log(employee);
                    db.close();                                
                }
            });
        }
   });
    /*Implement Employee.update*/    
    /*Implement Employee.remove*/    
},(err)=>{
    console.log('Error Occured:'+err);
});