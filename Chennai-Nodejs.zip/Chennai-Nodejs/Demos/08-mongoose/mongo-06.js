const mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

mongoose.connect('mongodb://localhost/SampleDB').then(()=>{
    let db = mongoose.connection.db;

    let Schema = mongoose.Schema;

    let Location = mongoose.model('location',new Schema({
        _id: Number,
        location: String
    }));

   /* Location.find((err,docs)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log(docs);
            db.close();
        }
    })*/

     /*Location.find({_id:{$gte:2}},{_id:0,location:1},{limit:3},(err,docs)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log(docs);
            db.close();
        }
     });*/

     /*Location.findOne((err,doc)=>{
        if(err){
            console.log(err);
        }
        else{
            console.log(doc);
            db.close();
        }
     });*/

     /*Location.findById(4,(err,doc)=>{
         if(err){
            console.log(err);
        }
        else{
            console.log(doc);
            db.close();
        }
     });*/

     let query = Location.where('_id').gte(2).lt(6).where('location').equals('Chennai');
     query.exec((err,docs)=>{
          if(err){
            console.log(err);
        }
        else{
            console.log(docs);
            db.close();
        }
     });
   
    
},(err)=>{
    console.log('Error Occured:'+err);
});