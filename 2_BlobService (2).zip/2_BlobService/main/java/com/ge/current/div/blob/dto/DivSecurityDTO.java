package com.ge.current.div.blob.dto;

public class DivSecurityDTO {
	
	private String sso;
	private String groupName;
	private String ssoDesc;
	public String getSso() {
		return sso;
	}
	public void setSso(String sso) {
		this.sso = sso;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getSsoDesc() {
		return ssoDesc;
	}
	public void setSsoDesc(String ssoDesc) {
		this.ssoDesc = ssoDesc;
	}
	

}
