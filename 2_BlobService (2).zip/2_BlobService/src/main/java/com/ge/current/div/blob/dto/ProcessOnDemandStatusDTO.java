package com.ge.current.div.blob.dto;

public class ProcessOnDemandStatusDTO {

	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
